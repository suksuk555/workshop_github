package com.example.test01;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Prac1 extends AppCompatActivity {

    Button mySend;

    EditText myMid,myFin,myFname;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_prac1);

        mySend=  findViewById(R.id.pSend);
        myMid =  findViewById(R.id.pMid);
        myFin =  findViewById(R.id.pFin);
        myFname = findViewById(R.id.pFname);

        final SharedPreferences sp = this.getSharedPreferences("shared_name", Context.MODE_PRIVATE);
        final SharedPreferences.Editor editor = sp.edit();





        mySend.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String fname = myFname.getText().toString();
                int mid = Integer.parseInt(myMid.getText().toString());
                int fin = Integer.parseInt(myFin.getText().toString());

                editor.putString("name",fname);
                editor.putInt("mid_term",mid); //column
                editor.putInt("final",fin);
                editor.commit();

                Toast.makeText(getApplicationContext(),"Sucessful",Toast.LENGTH_SHORT).show();

                Intent myIntend = new Intent(getApplicationContext(), Prac2.class);
//                myIntend.putExtra("my_fname",fname);
//                myIntend.putExtra("my_mid",mid);
//                myIntend.putExtra("my_fin",fin);
                startActivity(myIntend);
            }
        });


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.submitBTnew), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}