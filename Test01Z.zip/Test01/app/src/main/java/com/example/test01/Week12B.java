package com.example.test01;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Week12B extends AppCompatActivity {

    Button myOpen12C,myAD,myMapImg;


    EditText myScore12B;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_week12_b);


        myOpen12C = findViewById(R.id.open12C2);
        myAD = findViewById(R.id.viewAD2);
        myMapImg = findViewById(R.id.mapIMG2);

        myScore12B = findViewById(R.id.score12B);


        myOpen12C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String score = myScore12B.getText().toString();
                Intent myIntend = new Intent(getApplicationContext(), Week12C.class);
                myIntend.putExtra("my_score",score);
                startActivity(myIntend);
            }
        });

        myAD.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String geo = "geo:13.767547509080515,100.6095949980228?q=myhome";
                Intent myIntend = new Intent(Intent.ACTION_VIEW, Uri.parse(geo));
                startActivity(myIntend);
            }
        });

        myMapImg.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String geoCode = "http://maps.google.com/maps?saddr=9.938083,-84.054430&daddr=9.926392,-84.055964";
                Intent myIntend = new Intent(Intent.ACTION_VIEW, Uri.parse(geoCode));
                startActivity(myIntend);
            }
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.submitBTnew), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}