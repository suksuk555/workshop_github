package com.example.test01;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Week12C extends AppCompatActivity {

    Button myOpen12C, myStreet;

    TextView myResult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_week12_c);

        myOpen12C = findViewById(R.id.open12B);
        myStreet = findViewById(R.id.streetView);
        myResult = findViewById(R.id.result12C);


        Intent intent=  getIntent();
        String temp = intent.getStringExtra("my_score");
        myResult.setText("Result = "+temp);


        myStreet.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {


                String geoCode = "google.streetview:cbll=29.9774614,31.1329645&cbp=0,30,0,0,-15";
                Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(geoCode));
                startActivity(intent);


            }
        });


        myOpen12C.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent myIntend = new Intent(getApplicationContext(), Week12B.class);
                startActivity(myIntend);
            }
        });



        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.submitBTnew), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}