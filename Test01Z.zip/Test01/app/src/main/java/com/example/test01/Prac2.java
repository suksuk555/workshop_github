package com.example.test01;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Prac2 extends AppCompatActivity {

    TextView myShow;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_prac2);

        myShow = findViewById(R.id.pShow);

        Intent intent=  getIntent();

        final SharedPreferences sp = this.getSharedPreferences("shared_name", Context.MODE_PRIVATE);

        int midG = sp.getInt("mid_term",0);
        int finG = sp.getInt("final",0);
        String nameG = sp.getString("name","");


        myShow.setText("Hi Mr."+nameG+" "+"your score is "+(midG+finG));

//        String showFname = intent.getStringExtra("my_fname");
//        String showMid = intent.getStringExtra("my_mid");
//        String showFin = intent.getStringExtra("my_fin");
//
//        int showMidI = Integer.parseInt(showMid);
//        int showFinI = Integer.parseInt(showFin);
//
//
//
//
//
//        myShow.setText("Hi Mr."+showFname+" "+"your score is "+(showMidI+showFinI));


        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.submitBTnew), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}