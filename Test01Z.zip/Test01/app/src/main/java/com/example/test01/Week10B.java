package com.example.test01;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Week10B extends AppCompatActivity {


    EditText myNum1,myNum2;

    TextView myShowR;

    Button myBtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_week10_b);

        myNum1 = findViewById(R.id.num1);
        myNum2 = findViewById(R.id.num2);
        myShowR = findViewById(R.id.showResult);
        myBtn = findViewById(R.id.btnP);


        myBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                if(myNum1.getText().toString().equals("")){
                    myNum1.setError("Num1 is null");
                } else if (myNum2.getText().toString().equals("")) {
                    myNum2.setError("Num1 is null");
                }
                else {
                    int number1 = Integer.parseInt(myNum1.getText().toString());
                    int number2 = Integer.parseInt(myNum2.getText().toString());

                    int resault =  number1+number2;

                    myShowR.setText("The Resault is "+resault);
                }




            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.submitBTnew), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}