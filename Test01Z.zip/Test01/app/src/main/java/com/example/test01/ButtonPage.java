package com.example.test01;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class ButtonPage extends AppCompatActivity {

    Button myBtnRed,myBtnGreen,myBtnBlue,myBtnYellow,myBtnBlack;

    ImageView myPic;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_button_page);

        myBtnRed = findViewById(R.id.redBtn);
        myBtnGreen = findViewById(R.id.greenBtn);
        myBtnBlue = findViewById(R.id.blueBtn);
        myBtnYellow = findViewById(R.id.yellowBtn);
        myBtnBlack = findViewById(R.id.blackBtn);

        myPic  =  findViewById(R.id.pic);

        myBtnRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myPic.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.ired));
            }
        });

        myBtnGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myPic.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.igreen));
            }
        });
        myBtnBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myPic.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.iblue));
            }
        });
        myBtnYellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myPic.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.iyellow));
            }
        });
        myBtnBlack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                myPic.setImageDrawable(ContextCompat.getDrawable(getApplicationContext(),R.drawable.iblack));
            }
        });

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.submitBTnew), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}