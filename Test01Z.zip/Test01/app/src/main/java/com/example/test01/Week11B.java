package com.example.test01;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class Week11B extends AppCompatActivity {

    EditText myFname;

    Button mybtn;

    TextView myShow11B;
    Spinner mySp1,mySp2;

    CheckBox myCb1,myCb2;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_week11_b);

        myFname = findViewById(R.id.fname11B);
        mybtn = findViewById(R.id.btn11B);
        myShow11B = findViewById(R.id.show11B);

        mySp1= findViewById(R.id.spinner1);
        mySp2= findViewById(R.id.spinner2);

        myCb1 = findViewById(R.id.checkBox1);
        myCb2 = findViewById(R.id.checkBox2);

        myCb1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cName1 = myCb1.getText().toString();
                boolean ckecked = myCb1.isChecked();
                Toast.makeText(getApplicationContext(),ckecked+" male",Toast.LENGTH_SHORT).show();
            }
        });
        myCb2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String cName1 = myCb2.getText().toString();
                boolean ckecked = myCb2.isChecked();
                Toast.makeText(getApplicationContext(),ckecked+" check",Toast.LENGTH_SHORT).show();
            }
        });




        mybtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String sp1_new = mySp1.getSelectedItem().toString();
                String sp2_new = mySp2.getSelectedItem().toString();

                String fname = myFname.getText().toString();
                myShow11B.setText("Your name is "+fname+" "+sp1_new+" "+sp2_new);
                Toast.makeText(getApplicationContext(),"Your name is "+fname,Toast.LENGTH_SHORT).show();


            }
        });







        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.submitBTnew), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }
}